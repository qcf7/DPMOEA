

function [ris maxmod bestindividual population Neighbor]= firststep(M,gen,popSize,CrossoverFraction,mutationRate,similarity);


numberOfVariables = size(M,2);       %number of variables is the row-column number 

      
  for k=1:numberOfVariables  
    if ((sum(M(k,:))==0)) 
        Neighbor{k}=0;
        
    else   
  Neighbor{k} = find(M(k,:));
    end
  end

for k=1:numberOfVariables            
    if (Neighbor{k}==0) 
        bestNN(k)=0;
    else
      bestNN(k) = bestNeighbor(k,Neighbor);
    end
end
   
type create_populationLS.m;


type crossover_cluster1.m;


type mutate_cluster.m;

%type cluster_fitness.m
type cluster_fitnessMod.m;  

%FitnessFcn = @(x)cluster_fitness(x,M,alfa);
FitnessFcn = @(x)cluster_fitnessMod(x,M);

 
 
options = gaoptimset('PopulationType', 'custom','PopInitRange', ...
    [1;numberOfVariables]);

Elitecount=(options.PopulationSize*10)/100;
%mutationRate=0.6;
%CrossoverFraction=0.8;
options = gaoptimset(options,'CreationFcn',{@create_populationLS1,bestNN,Neighbor}, ...
    'CrossoverFcn',{@crossover_cluster2,Neighbor,M},...
    'MutationFcn',{@mutate_cluster2, mutationRate,Neighbor}, ...
    'PlotFcn', {@plotfun,@gaplotscores,@gaplotscores,@gaplotrange}, ...
    'SelectionFcn',@selectionroulette, ...
    'Generations',gen,'PopulationSize',popSize, ...
    'StallTimeLimit',Inf, ...
    'StallGenLimit',100,'Vectorized','on');


[x,fval,reason,output,population,scores] = ga(FitnessFcn,numberOfVariables,options);
for n=1:size(population,1)
       CC=decodenew(population(n,:));
       population(n,:)=celltolabel(CC,numberOfVariables);
end

hebing=[scores population];
hebing=sortrows(hebing,1);
population=hebing(:,2:size(hebing,2));

e=randperm(75,25)+25;
for o=1:size(e,2)
     population(o+25,:)=population(e(o),:);
end

%fval
[maxmod i] = min(fval(:,1));
maxmod=-maxmod;
ris=decodenew(x(i,:));
bestindividual=x(i,:);

 
function pos=bestNeighbor(node,Neighbor) 
maxshared=-1;
pos=0;
%Neighbor{node}
for j=1:size(Neighbor{node},2)
    if (j ~= node)
       vicino=Neighbor{node}(j);
       shared=size(intersect(Neighbor{node},Neighbor{vicino}),2);
       if(shared > maxshared)
        maxshared=shared;
        pos=j;
       end
    end
end
end
end
