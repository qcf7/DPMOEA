function child = increment_creation(child,Neighbor,pos,bestCC,similarity,addnode,add,minusnode,minus,M,last_Neighbor,degree)
    
        
        if find(addnode==pos)
            similariest_pos=neighbor_similarity(Neighbor,pos,bestCC,similarity);
            vectorAfter=child;
            vectorAfter(pos)=child(similariest_pos);
            deltaQ=getDeltaModularity3(M, degree,pos,child, vectorAfter);
            if deltaQ>0
            child(pos)=child(similariest_pos);
            end
        end
        if find(add==pos)
            similariest_pos=neighbor_similarity(Neighbor,pos,bestCC,similarity);
            vectorAfter=child;
            vectorAfter(pos)=child(similariest_pos);
            deltaQ=getDeltaModularity3(M, degree,pos,child, vectorAfter);
            if deltaQ>0
            child(pos)=child(similariest_pos);
            end
            if flag==1
            for u=1:size(last_Neighbor{1,pos},2)
               if Neighbor{1,last_Neighbor{1,pos}(u)}==0
                     continue
               end
                 
            similariest_pos=neighbor_similarity(Neighbor,last_Neighbor{1,pos}(u),bestCC,similarity);
            vectorAfter=child;
            vectorAfter(last_Neighbor{1,pos}(u))=child(similariest_pos);
            deltaQ= getDeltaModularity3(M, degree,last_Neighbor{1,pos}(u),vectorBefore, vectorAfter);
            if deltaQ>0
            child(last_Neighbor{1,pos}(u))=child(similariest_pos);
            end
                 
                 
            end
                
            end
            
            
        end
        if find(minusnode==pos)
          
             for u=1:size(last_Neighbor{1,pos},2)
                 if Neighbor{1,last_Neighbor{1,pos}(u)}==0
                     continue
                 end
                 
            similariest_pos=neighbor_similarity(Neighbor,last_Neighbor{1,pos}(u),bestCC,similarity);
            vectorAfter=child;
            vectorAfter(last_Neighbor{1,pos}(u))=child(similariest_pos);
            deltaQ= getDeltaModularity3(M, degree,last_Neighbor{1,pos}(u),child, vectorAfter);
            if deltaQ>0
            child(last_Neighbor{1,pos}(u))=child(similariest_pos);
            end
                 
                 
             end
                  
        end
        
        if find(minus==pos)
        similariest_pos=neighbor_similarity(Neighbor,pos,bestCC,similarity);
            vectorAfter=child;
            vectorAfter(pos)=child(similariest_pos);
            deltaQ=getDeltaModularity3(M, degree,pos,child, vectorAfter);
            if deltaQ>0
            child(pos)=child(similariest_pos);
            end
        
             if flag==1
            for u=1:size(last_Neighbor{1,pos},2)
               if Neighbor{1,last_Neighbor{1,pos}(u)}==0
                     continue
               end
                 
            similariest_pos=neighbor_similarity(Neighbor,last_Neighbor{1,pos}(u),bestCC,similarity);
            vectorAfter=child;
            vectorAfter(last_Neighbor{1,pos}(u))=child(similariest_pos);
            deltaQ = getDeltaModularity3(M, degree,last_Neighbor{1,pos}(u),child, vectorAfter);
            if deltaQ>0
            child(last_Neighbor{1,pos}(u))=child(similariest_pos);
            end
                 
                 
            end
                
            end
        end
        

        
end

