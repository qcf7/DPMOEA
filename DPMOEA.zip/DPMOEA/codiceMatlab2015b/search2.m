function [label flag NodeNeighbor] = search2(changeNode,NodeNeighbor,label,labelafter,M,degree)
flag=0;
labelafter=label;
            for y=1:30
                  if NodeNeighbor==0
                      break
                  end
                  if size(NodeNeighbor,2)==1
                      randnum=1;
                  else
                  randnum=randperm(size(NodeNeighbor,2)-1,1)+1;
                  end
                  labelafter(changeNode)=labelafter(NodeNeighbor(randnum));
                  if getDeltaModularity3(M, degree, changeNode, label, labelafter)>=0
                        label = labelafter;
                        flag=1;
                        break
                  else
                      
                      labelafter=label;
                  end
            end
