function CC = label2CC(label)
memory=[];
CC=[];
for i=1:size(label,2)
    if isempty(find(memory==label(i)))
        CC=[CC {find(label==label(i))}];
           memory=[memory label(i)];
    end
end

