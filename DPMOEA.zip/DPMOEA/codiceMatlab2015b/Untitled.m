% 输入的向量
input_vector = [1, 2, 3, 4, 5, 6];

% 计算输入向量的长度
n = length(input_vector);

% 计算输出矩阵的行数
output_rows = n / 2;

% 初始化输出矩阵
output_matrix = reshape(input_vector, 2, output_rows)';

% 显示输出矩阵
disp(output_matrix);
