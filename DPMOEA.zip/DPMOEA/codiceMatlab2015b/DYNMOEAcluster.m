function [ris maxmod bestindividual population Neighbor] = DYNMOEAcluster(M,class,numClass,gen,popSize,CrossoverFraction,mutationRate,T,bestindividual,best_pops,addnode,add,minusnode,minus,last_Neighbor,incre);
global state;
global Neighbor;
numberOfVariables = size(M,1);       


for k=1:numberOfVariables  
    if ((sum(M(k,:))==0)) 
        Neighbor{k}=0;
        
    else   
  Neighbor{k} = find(M(k,:));
    end
end
 

for k=1:numberOfVariables  
      
    if (Neighbor{k}==0) 
        bestNN(k)=0;
    else
        bestNN(k) = bestNeighbor(k,Neighbor);
    end
end

type create_populationLS.m;


type crossover_cluster.m;

type mutate_cluster.m;




type DYNMOcluster_fitnessMOD.m;


FitnessFcn = @(x)DYNMOcluster_fitnessMOD(x,M,class,numClass,numberOfVariables);
 
 
options = gaoptimset('PopulationType', 'custom','PopInitRange', ...
    [1;numberOfVariables]);

Elitecount=(options.PopulationSize*10)/100;

options = gaoptimset(options,'CreationFcn',{@create_populationLS,bestNN,Neighbor,best_pops,addnode,minusnode,M,add,minus,T,bestindividual,last_Neighbor}, ...
    'CrossoverFcn',{@crossover_cluster},...
    'MutationFcn',{@mutate_cluster, mutationRate,Neighbor,M,incre}, ...        
    'PlotFcn', {@plotfun,@gaplotscores,@gaplotpareto,@gaplotscorediversity}, ...
    'SelectionFcn',@selectiontournament, ...
    'Generations',gen,'PopulationSize',popSize, ...
    'StallTimeLimit',Inf, ...
    'StallGenLimit',100,'Vectorized','on');
% 'paretoFraction',0.5
% 'MutationFcn',{@mutate_cluster, mutationRate,Neighbor,addnode,add,minusnode,minus,T}, ...
lb=[];
% options1 = gaoptimset(options,'CreationFcn',{@create_populationLS,bestNN,Neighbor,best_pops,addnode,minusnode,M,add,minus,T,bestindividual}, ...
%     'CrossoverFcn',{@crossover_cluster},...
%     'MutationFcn',{@mutate_cluster1, mutationRate,Neighbor}, ...
%     'PlotFcn', {@plotfun,@gaplotscores,@gaplotpareto,@gaplotscorediversity}, ...
%     'SelectionFcn',@selectiontournament, ...
%     'Generations',gen,'PopulationSize',[popSize/2,popSize/2], ...
%     'StallTimeLimit',Inf, ...
%     'StallGenLimit',20,'Vectorized','on');
ub=[];
    
[x,fval,reason,output,population,scores] = gamultiobj(FitnessFcn,numberOfVariables,[],[],[],[],lb,ub,options);
for n=1:size(population,1)
       CC=decodenew(population(n,:));
       population(n,:)=celltolabel(CC,numberOfVariables);
end
rank=state.Rank;
hebing=[rank population];
hebing=sortrows(hebing,1);
population=hebing(:,2:size(hebing,2));
e=randperm(67,33)+33;
for o=1:size(e,2)
     population(o+33,:)=population(e(o),:);
end
fname = ['result_x_fval.mat'];
           

            eval(['save ' fname  ' x fval -mat']);
%fval
%plotpareto(fval)
[maxmod i] = min(fval(:,1)); % 1 chooses la best modularity,  2 the best nmi 
maxmod=-maxmod;


ris =decodenew(x(i,:));
bestindividual = x(i,:);
function pos=bestNeighbor(node,Neighbor) 
maxshared=-1;
pos=0;

for j=1:size(Neighbor{node},2)
    if (j ~= node)
       vicino=Neighbor{node}(j);
       
       shared=size(intersect(Neighbor{node},Neighbor{vicino}),2);
       if(shared > maxshared)
        maxshared=shared;
        pos=j;
       end
    end
end
end

end

