function mat = adj(couple)
numNodes=max(max(couple));
mat=zeros(numNodes,numNodes);

for i=1:size(couple,1)
    mat(couple(i,1),couple(i,2)) = 1;
    mat(couple(i,2),couple(i,1)) = 1;
end
end

