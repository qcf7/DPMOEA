function average = CC_similarity(node,CC,similarity)
if find(CC==node)
   sum=0;
   for i=1:size(CC,2)
      sum=sum+similarity(node,CC(i));
   end
   average=sum/(size(CC,2)-1);

else
   sum=0;
   for i=1:size(CC,2)
   sum=sum+similarity(node,CC(i));
   end
   average=sum/size(CC,2);
end
end

% 该函数原本为averagesim，作用是计算一个节点与一个社团的平均相似度