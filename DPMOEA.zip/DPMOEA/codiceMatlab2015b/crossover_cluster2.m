function xoverKids  = crossover_cluster2(parents,options,NVARS, ...
    FitnessFcn,thisScore,thisPopulation,Neighbor,M);
global state;
%   The arguments to the function are 
%     PARENTS: Parents chosen by the selection function
%     OPTIONS: Options structure created from GAOPTIMSET
%     NVARS: Number of variables 
%     FITNESSFCN: Fitness function 
%     STATE: State structure used by the GA solver 
%     THISSCORE: Vector of scores of the current population 
%     THISPOPULATION: Matrix of individuals in the current population



% if state.Generation>90
%  y=find(thisScore(:,1)==min(thisScore(:,1)));
%  bestsolution10=thisPopulation(y(1),:);
%  changebest=bestsolution10-bestsolution;
%  changenode=find(changebest~=0);
%  changeNeighbor=[];
% 
%  for o=1:size(changenode,2)
%    changeNeighbor=[changeNeighbor Neighbor{1,changenode(o)}]; 
%  end
% if isempty(changenode)==1
% flag=0;
% else
%  flag=1;
%  localpop=localsearch(M, Neighbor, changeNeighbor, thisPopulation);
% end
% bestsolution=bestsolution10;
% end
if mod(state.Generation,10)==0
     NVARS=size(thisPopulation(1,:),2);
     changeNeighbor=zeros(1,NVARS);
for h=1:NVARS
    changeNeighbor(h)=h;
    
end
localpop=localsearch(M, Neighbor, changeNeighbor, thisPopulation);

end






nKids = length(parents)/2;
xoverKids = zeros(nKids,NVARS); 
index = 1;

for i=1:nKids
    % get parents
   
    r1 = thisPopulation(parents(index),:);
    index = index + 1;
    r2 =thisPopulation(parents(index),:);
    index = index + 1;
    % Randomly select one gene from each parent
    
    for j = 1:size(r1,2)
        prob=rand;
        if(prob > 0.5)
            child(1,j) = r1(1,j);
        else
          child(1,j) = r2(1, j);
        end
    end
    xoverKids(i,:) = child; 
   

end
if mod(state.Generation,20)==0 
l=size(localpop,1);
xoverKids(1:l,:)=localpop;
end