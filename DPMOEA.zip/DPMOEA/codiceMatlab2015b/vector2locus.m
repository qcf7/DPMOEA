function lbSolution = vector2locus(vbSolution, AdjMatrix)
lbSolution = zeros(1, length(vbSolution));
maxClu = max(vbSolution);
for clu = 1:maxClu
    allNodes = find(vbSolution==clu);
    if length(allNodes)==1
        lbSolution(allNodes) = allNodes;
    elseif ~isempty(allNodes)
        firstOne = allNodes(unidrnd(length(allNodes)));
        done = [firstOne];
        while length(done)<length(allNodes) && ~any(AdjMatrix(firstOne,:)&vbSolution==clu)
            neighbors = find(AdjMatrix(firstOne, :));
            lbSolution(firstOne) = unidrnd(length(neighbors));
            diff = setdiff(allNodes, done);
            firstOne = diff(unidrnd(length(diff)));
            done = [done firstOne];
        end
        if length(done) < length(allNodes)
            lbSolution(firstOne) = find(AdjMatrix(firstOne,:)&vbSolution==clu, 1);
        else
            neighbors = find(AdjMatrix(firstOne, :));
            lbSolution(firstOne) = unidrnd(length(neighbors));
        end
        while length(done) < length(allNodes)
            lastlength = length(done);
            for v = allNodes
                if lbSolution(v)==0 && any(AdjMatrix(v, done))
                    lbSolution(v) = done(find(AdjMatrix(v, done),1));
                    done = [done v];
                end
              
            end
            if lastlength == length(done)
                diff = setdiff(allNodes, done);
                v = diff(unidrnd(length(diff)));
                lbSolution(v) = find(AdjMatrix(firstOne,:)&vbSolution==clu, 1);
               
                done = [done v];
            end
        end
    end
end
for i=1:size(lbSolution,2)
    if isnan(lbSolution(i))
       lbSolution(i)=i; 
    end
end