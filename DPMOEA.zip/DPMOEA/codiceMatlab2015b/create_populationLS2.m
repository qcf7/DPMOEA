function pop = create_populationLS2(NVARS,FitnessFcn,options,bestNeig,Neighbor,transfer_pops,addnode,minusnode,M,add,minus,T,bestindividual,last_Neighbor);
%CREATE_POPULATION Creates a population of chromosome.


similarity=Tosim_matrix(M,1);
% 将相似度大于important_rate的边作为重要边，主要对这些边进行计算
important_rate=0.9;
add=important_edge(similarity,add,important_rate);
minus=important_edge(similarity,minus,important_rate);
totalPopulationSize = sum(options.PopulationSize);
pop = zeros(totalPopulationSize,NVARS);
rand('twister',sum(1000*clock));
prob=0.5;
bestCC=decodenew(bestindividual);
for i = 1:totalPopulationSize

    for k=1:NVARS
        
        if (Neighbor{k} == 0) 
            
            chrom(k)=0;
        else
            
                 
                position = ceil(size(Neighbor{k},2)*rand);
             
            
             chrom(k)= Neighbor{k}(position);
        end
    end
   
     pop(i,:) = chrom;

end
    degree=Neighbor2degree(Neighbor);
for n=1:size(transfer_pops,1)/10
    for l=1:size(transfer_pops,2)
        transfer_pops(n,:)=increment_creation(transfer_pops(n,:),Neighbor,l,bestCC,similarity,addnode,add,minusnode,minus,M,last_Neighbor,degree);
    end
end



for q=1:size(transfer_pops,1)/10
transfer_pops(q,:)=vector2locus(transfer_pops(q,:),M);
end

% for m=size(transfer_pops,1)/4
%     for n=1:size(transfer_pops,2) 
%         if rand<0.3
%             position = ceil(size(Neighbor{n},2)*rand);
%             transfer_pops(m,n)= Neighbor{n}(position);
% 
%         end
%     end
% end

l=size(transfer_pops,1);

% for m=1:l
%     for n=1:size(transfer_pops,2)
%     if transfer_pops(m,n)==0||isempty(find(Neighbor{1,n}==transfer_pops(m,n)))
%         pos = ceil(size(Neighbor{n},2)*rand);
%         transfer_pops(m,n)= Neighbor{n}(pos);
%     end
%     end
% end
for i=1:size(transfer_pops,1)
    for u=1:size(transfer_pops,2)
if isempty(find(Neighbor{1,u}==transfer_pops(i,u)))
     position = ceil(size(Neighbor{u},2)*rand);
     transfer_pops(i,u)=Neighbor{1,u}(position);
end
    end
end
for q=1:size(minusnode,2)
    transfer_pops(:,minusnode(q))=0;
end
    pop(1:l/10,:)=transfer_pops(1:l/10,:);
% 
% 对于迁移解做简单处理，0位点随机选邻居，减的点放0
% 一半旧解一半处理解
end
