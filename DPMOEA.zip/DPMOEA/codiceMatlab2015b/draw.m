figure(1)
clf
hold on

tt = mean(a1,1);
plot(2:length(tt)+1, tt, 'r-*', 'LineWidth', 1.5); % 修改这里，使用长度作为横坐标，线条加粗
tt = mean(a2,1);
plot(2:length(tt)+1, tt, 'b-o', 'LineWidth', 1.5);
tt = mean(a3,1);
plot(2:length(tt)+1, tt, 'g-s', 'LineWidth', 1.5);
tt = mean(a4,1);
plot(2:length(tt)+1, tt, 'c-p', 'LineWidth', 1.5);
tt = mean(a5,1);
plot(2:length(tt)+1, tt, 'y-*', 'LineWidth', 1.5);
%  tt = mean(a7,1);
%  plot(1:length(tt)+1, tt, 'w-', 'LineWidth', 1.5); 

% tt = mean(a1,1);
% plot(1:length(tt), tt, 'r-*', 'LineWidth', 1.5); 
xticks(2:1:length(a1)+1); % 设置 x 轴刻度为 1 到数据长度，每隔一个单位
xlim([2, length(a1)+1]); % 设置 x 轴范围从 1 到数据长度


legend('DPMOEA','DECS','DYNMOGA','TMOGA','HOKT');
xlabel('Time Steps');
ylabel('HV');
title('Hypervolume over Time');

% 放大字体
set(gca, 'FontSize', 16); % 设置坐标轴上的字体大小
set(get(gca, 'XLabel'), 'FontSize', 16); % 设置 x 轴标签的字体大小
set(get(gca, 'YLabel'), 'FontSize', 16); % 设置 y 轴标签的字体大小
set(get(gca, 'Title'), 'FontSize', 18); % 设置标题的字体大小
set(legend, 'FontSize', 13); % 设置图例的字体大小

% 设置 x 轴刻度


linehandler = get(gca, 'Children');
% set(linehandler, 'MarkerSize', marksize, 'LineWidth', linewidth);
