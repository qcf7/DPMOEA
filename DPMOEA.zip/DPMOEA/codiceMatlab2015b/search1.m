function label = search1(changeNode,NodeNeighbor,label,labelafter,M,degree,Expectnode)

             labelafter=label;
if Expectnode~=0
             labelafter(changeNode)=labelafter(Expectnode);
end
                  if getDeltaModularity3(M, degree, changeNode, label, labelafter)>0
                        label = labelafter;
                   
                    
                  else
                      
                      labelafter=label;
                  



            for y=1:30
                  if NodeNeighbor==0
                      break
                  end
                  if size(NodeNeighbor,2)==1
                      randnum=1;
                  else
                  randnum=randperm(size(NodeNeighbor,2)-1,1)+1;
                  end
                  labelafter(changeNode)=labelafter(NodeNeighbor(randnum));
                  if getDeltaModularity3(M, degree, changeNode, label, labelafter)>=0
                        label = labelafter;
                       
                        break
                  else
                      
                      labelafter=label;
                  end
            end
                  end