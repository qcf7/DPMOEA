function mutationChildren = mutate_cluster(parents ,options,NVARS, ...
    FitnessFcn, state, thisScore,thisPopulation,mutationRate,Neighbor,M,incre);
%
%   The arguments to the function are 
%     PARENTS: Parents chosen by the selection function
%     OPTIONS: Options structure created from GAOPTIMSET
%     NVARS: Number of variables 
%     FITNESSFCN: Fitness function 
%     STATE: State structure used by the GA solver 
%     THISSCORE: Vector of scores of the current population 
%     THISPOPULATION: Matrix of individuals in the current population
%     MUTATIONRATE: Rate of mutation
%     Neighbor a cell array containing the neighbors of each node
if mod(state.Generation,10)==0
important_rate=0;
similarity=Tosim_matrix(M,1);
add=important_edge(similarity,incre.add,important_rate);
minus=important_edge(similarity,incre.minus,important_rate);
addnode=incre.addnode;
minusnode=incre.minusnode;
minus_neigh=incre.minus_neigh;
if ~isempty(addnode)
 [localpop q]=localsearch1(M, Neighbor, addnode, thisPopulation);
 for i=1:size(q,2)
    thisPopulation(q(i),:)=localpop(i,:);
 end
end
if ~isempty(add)
 [localpop q]=localsearch1(M, Neighbor, add,thisPopulation);
  for i=1:size(q,2)
    thisPopulation(q(i),:)=localpop(i,:);
 end
end
if ~isempty(minus)
 localpop=localsearch1(M, Neighbor, minus,thisPopulation);
 for i=1:size(q,2)
    thisPopulation(q(i),:)=localpop(i,:);
 end
end
if ~isempty(minus_neigh)
 localpop=localsearch1(M, Neighbor, minus_neigh,thisPopulation);
 for i=1:size(q,2)
    thisPopulation(q(i),:)=localpop(i,:);
 end
end


else
mutationChildren = zeros(length(parents),NVARS);


for i=1:length(parents)
  

        child = thisPopulation(parents(i),:);
        for q=1:size(child,2)
        if rand<0.001
        pos = q;
        while (child(pos) == 0) 
            pos = ceil(NVARS*rand);
        end
        valuepos=ceil(size(Neighbor{pos},2)*rand);

        child(pos) = Neighbor{pos}(valuepos);
        end
        end
        mutationChildren(i,:) = child;    
end
end
%  if state.Generation==80
%      changeNeighbor=zeros(1,1000);
% for h=1:1000
%     changeNeighbor(h)=h;
%     
% end
% localpop=localsearch(M, Neighbor, changeNeighbor, thisPopulation);
%  end
if mod(state.Generation,10)==0
l=size(localpop,1);
mutationChildren(1:l,:)=localpop;
end