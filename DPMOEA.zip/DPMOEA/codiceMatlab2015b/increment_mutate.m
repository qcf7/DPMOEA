function child = increment_mutate(child,Neighbor,pos,bestCC,similarity,addnode,add,minusnode,minus,M,degree,last_Neighbor)

flag=0;
        if find(addnode==pos)
            similariest_pos=neighbor_similarity1(Neighbor,pos,bestCC,similarity);
            vectorAfter=child;
            vectorAfter(pos)=similariest_pos;
            deltaQ=getDeltaModularity4(M, degree,pos,child, vectorAfter);
            if deltaQ>0
            child(pos)=similariest_pos;
            end
           
       
        end
        if find(add==pos)
            similariest_pos=neighbor_similarity1(Neighbor,pos,bestCC,similarity);
            vectorAfter=child;
            vectorAfter(pos)=similariest_pos;
            deltaQ=getDeltaModularity4(M, degree,pos,child, vectorAfter);
            if deltaQ>0
            child(pos)=similariest_pos;
            flag=1;
            end
           
        
       
            if flag==1
            for u=1:size(last_Neighbor{1,pos},2)
               if Neighbor{1,last_Neighbor{1,pos}(u)}==0
                     continue
               end
                 
            similariest_pos=neighbor_similarity(Neighbor,pos,bestCC,similarity);
            vectorAfter=child;
            vectorAfter(pos)=similariest_pos;
            deltaQ=getDeltaModularity4(M, degree,pos,child, vectorAfter);
            if deltaQ>0
            child(pos)=similariest_pos;
            end
                 
                 
            end
            end
        end
        if find(minus==pos)
             for u=1:size(last_Neighbor{1,pos},2)
                 if Neighbor{1,last_Neighbor{1,pos}(u)}==0
                     continue
                 end
                 
            similariest_pos=neighbor_similarity(Neighbor,last_Neighbor{1,pos}(u),bestCC,similarity);
            vectorAfter=child;
            vectorAfter(last_Neighbor{1,pos}(u))=similariest_pos;
            deltaQ= getDeltaModularity4(M, degree,last_Neighbor{1,pos}(u),child, vectorAfter);
            if deltaQ>0
            child(last_Neighbor{1,pos}(u))=similariest_pos;
            end
                 
                 
             end
                
        end
        
        
         if find(minusnode==pos)
          
             for u=1:size(last_Neighbor{1,pos},2)
                 if Neighbor{1,last_Neighbor{1,pos}(u)}==0
                     continue
                 end
                 
            similariest_pos=neighbor_similarity(Neighbor,last_Neighbor{1,pos}(u),bestCC,similarity);
            vectorAfter=child;
            vectorAfter(last_Neighbor{1,pos}(u))=similariest_pos;
            deltaQ= getDeltaModularity4(M, degree,last_Neighbor{1,pos}(u),child, vectorAfter);
            if deltaQ>0
            child(last_Neighbor{1,pos}(u))=similariest_pos;
            end
                 
                 
             end
                  
        end
        
        
end

