function mutationChildren = mutate_cluster1(parents ,options,NVARS, ...
    FitnessFcn, state, thisScore,thisPopulation,mutationRate,Neighbor,M,incre,last_Neighbor,bestindividual);
%
%   The arguments to the function are 
%     PARENTS: Parents chosen by the selection function
%     OPTIONS: Options structure created from GAOPTIMSET
%     NVARS: Number of variables 
%     FITNESSFCN: Fitness function 
%     STATE: State structure used by the GA solver 
%     THISSCORE: Vector of scores of the current population 
%     THISPOPULATION: Matrix of individuals in the current population
%     MUTATIONRATE: Rate of mutation
%     Neighbor a cell array containing the neighbors of each node
global bestsolution;
if mod(state.Generation,20)==0
similarity=Tosim_matrix(M,1);
% 将相似度大于important_rate的边作为重要边，主要对这些边进行计算
important_rate=0;
add=important_edge(similarity,incre.add,important_rate);
minus=important_edge(similarity,incre.minus,important_rate);
addnode=incre.addnode;
minusnode=incre.minusnode;
totalPopulationSize = sum(options.PopulationSize);
pop = zeros(totalPopulationSize,NVARS);
bestCC=decodenew(bestindividual);


degree=Neighbor2degree(Neighbor);


% 
% if state.Generation==1
% y=find(thisScore(:,1)==min(thisScore(:,1)));
% bestsolution=thisPopulation(y,:);
% end

% if mod(state.Generation,20)==0
%  y=find(thisScore(:,1)==min(thisScore(:,1)));
%  bestsolution10=thisPopulation(y(1),:);
%  changebest=bestsolution10-bestsolution;
%  changenode=find(changebest~=0);
%  changeNeighbor=[];
% 
%  for o=1:size(changenode,2)
%    changeNeighbor=[changeNeighbor Neighbor{1,changenode(o)}]; 
%  end
% if isempty(changenode)==1
% flag=0;
% else
%  flag=1;
%  localpop=localsearch1(M, Neighbor, changeNeighbor, thisPopulation);
% end
% bestsolution=bestsolution10;
% end


mutationChildren = zeros(length(parents),NVARS);


for i=1:length(parents)
  

        child = thisPopulation(parents(i),:);
        if rand<0.25
        for q=1:size(child,2)
            if ~(isempty(find(addnode==q))&&isempty(find(add==q))&&isempty(find(minusnode==q))&&isempty(find(minus==q)))
                
                     
                    child=increment_mutate(child,Neighbor,q,bestCC,similarity,addnode,add,minusnode,minus,M,degree,last_Neighbor);
                
                
            end
       
        end
        end
        mutationChildren(i,:) = child;    
end
else
    
    mutationChildren = zeros(length(parents),NVARS);


for i=1:length(parents)
  

        child = thisPopulation(parents(i),:);
        for q=1:size(child,2)
        if rand<0.001
        pos = q;
        while (child(pos) == 0) 
            pos = ceil(NVARS*rand);
        end
        valuepos=ceil(size(Neighbor{pos},2)*rand);

        child(pos) = Neighbor{pos}(valuepos);
        end
        end
        mutationChildren(i,:) = child; 
    
    
end



end
%  if state.Generation==80
%      changeNeighbor=zeros(1,1000);
% for h=1:1000
%     changeNeighbor(h)=h;
%     
% end
% localpop=localsearch(M, Neighbor, changeNeighbor, thisPopulation);
%  end
% if mod(state.Generation,20)==0 && flag==1
% l=size(localpop,1);
% mutationChildren(1:l,:)=localpop;
% end