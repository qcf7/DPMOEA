 function [dynMoeaResult]= run_DYNMOEAmain(W_Cube,nbCluster,gen,popSize,CrossoverFraction,mutationRate);
numtimestamp=size(W_Cube,2);
dynMoeaResult=[];

load('birthdeath5.mat');


similarity=eval(['embedding' num2str(1)]);
similarity=cosimilarity(similarity);
[fid, message] = fopen('Ris.txt','wt');


M1=sparse(W_Cube{1});


timetot=0; 
alfa=2;
numberOfVariables = size(M1,1);       %number of variables is the row-column number 
%tic
[currsol miglioremod bestindividual transfer_pops transfer_Neighbor]=firststep(M1,gen,popSize,CrossoverFraction,mutationRate,similarity); %Solution at tme step 0 without the second objective
%time=toc
%timetot=timetot+time
bestCC=currsol;

class=zeros(numberOfVariables,2);
Neighbor1=transfer_Neighbor;
%disp('number of obtained clusters')
numClass=size(currsol,2); 

fprintf(fid,'timestamp: 0 modularity=%d  numClusters=%d\n',miglioremod,numClass);


for i=1:numClass
    listnodes=currsol{i};
    for j=1 : size(listnodes,2)
        class(listnodes(1,j),2)=i;%class vector obtained for each node 
        class(listnodes(1,j),1)=listnodes(1,j); 
    end
end



dynMoeaResult(:,1)=class(:,2);

for numiter=2:numtimestamp
 M=sparse(W_Cube{numiter});     
[addnode add minusnode minus minus_neigh]=increment_infor(W_Cube,M1,numiter,bestCC,transfer_Neighbor);
   incre=struct('addnode',{addnode},'add',{add},'minusnode',{minusnode},'minus',{minus},'minus_neigh',{minus_neigh});
%tic
[bestCC miglioremod bestindividual transfer_pops transfer_Neighbor]=DYNMOEAcluster(M,class,numClass,gen,popSize,CrossoverFraction,mutationRate,numiter,bestindividual,transfer_pops,addnode,add,minusnode,minus,transfer_Neighbor,incre);
%time=toc
%timetot=timetot+time


numClass=size(bestCC,2);


clear class;

class=zeros(numberOfVariables,2);

%compute the classes for the solution  bestCC
%these classes will be considered as the true classes at the next timestamp
%class contains the node in the first position and the corresponding class
%in the second one


for i=1:numClass
    listnodes=bestCC{i};
    if (size(listnodes,2) ==1) & (W_Cube{numiter}(listnodes(1,1))==0)
        disp('error, we are considering null node')
        listnodes(1,1)
        W_Cube{numiter}(listnodes(1,1))
        class(listnodes(1,1),2)=0;
        class(listnodes(1,1),1)=0;
    else
    for j=1 : size(listnodes,2)
        class(listnodes(1,j),2)=i;
        class(listnodes(1,j),1)=listnodes(1,j); 
    end
    end
end
dynMoeaResult(:,numiter)=class(:,2);
% if numiter==2
% similarity=Tosim_matrix(M1,1);
% % 将相似度大于important_rate的边作为重要边，主要对这些边进行计算
% important_rate=0.9;
% add=important_edge(similarity,add,important_rate);
% minus=important_edge(similarity,minus,important_rate);
% degree=Neighbor2degree(Neighbor1);
% for k=1:numberOfVariables  
%     if ((sum(M(k,:))==0)) 
%         Neighbor{k}=0;
%         
%     else   
%   Neighbor{k} = find(M(k,:));
%     end
% end
% improver=dynMoeaResult(:,1)';
% for l=1:numberOfVariables
% improver=increment_creation(improver,Neighbor1,l,bestCC,similarity,minusnode,minus,addnode,add,M1,Neighbor,degree);
% end
% CC1=label2CC(improver);
% Modularity(1)=modularity(CC1,M1);
% dynMoeaResult(:,1)=improver';
% 
% end
fprintf(fid,'timestamp: %d modularity=%d  numClusters=%d\n',numiter,miglioremod,numClass);

fprintf(fid,'best partitioning: \n');

for i1 = 1:size(bestCC,2)
    
    listnodes=bestCC{i1};
    for j1= 1:size(listnodes,2)
       
            fprintf(fid,'%d ',listnodes(1,j1));
    end
    fprintf(fid,'\n');
end


 fprintf(fid,'\n clusters: \n');
% 
 for i = 1:numberOfVariables
     for j= 1:2
        
             fprintf(fid,'%d ',class(i,j));
     end
     fprintf(fid,'\n');
 end
 M1=M;
 end


end
        

