function similariest_pos= neighbor_similarity1(Neighbor,node,bestCC,similarity)
% 社团归属划分的locus形式
simi_list=[];
CC_label=[];
CC_represent=[];
for v=1:size(Neighbor{1,node},2)
        
        for q=1:size(bestCC,2)
            
           if(find(bestCC{1,q}==Neighbor{1,node}(v)))
               u=CC_similarity(node,bestCC{1,q},similarity); 
               simi_list=[simi_list u]; 
               CC_label=[CC_label q];
               CC_represent=[CC_represent Neighbor{1,node}(v)];
               break
           end
        end
end

if isempty(simi_list)
     position = ceil(size(Neighbor{1,node},2)*rand);
     similariest_pos=Neighbor{1,node}(position);
     return
end
similariest_CC=find(simi_list==max(simi_list));
similariest_CC=similariest_CC(1);

if rand>0.5
similariest_pos=CC_label(similariest_CC(1));
else
     position = ceil(size(Neighbor{1,node},2)*rand);
     similariest_pos=Neighbor{1,node}(position);
end


end

