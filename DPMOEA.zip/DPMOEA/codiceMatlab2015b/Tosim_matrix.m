function S=Tosim_matrix(NetM,beta)
%  S :similarity
%  DS:dissimilarity
% 扩散核相似度0
degree=sum(NetM);         % degree
Net_size=length(degree);
LL=diag(degree)-NetM;     % Laplacian matrix

N=expm(-beta*LL);         % Diffusion kernel         
dd=diag(N);

% normalization
for i=1:Net_size
    for j=1:Net_size
     S(i,j)=N(i,j)/sqrt(dd(i)*dd(j));        
     if S(i,j)==1
         S(i,j)=0;
     end
   end
end
  
