function degree = Neighbor2degree(neighbor)
degree=[];
for i=1:size(neighbor,2)
    
    a=size(neighbor{1,i},2);
    degree=[degree a];
end

