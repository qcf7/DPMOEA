function [addnode add minusnode minus minus_Neighbor] = increment_infor(W_Cube,M1,numiter,bestCC,transfer_Neighbor)
% 该函数统计增量信息

M=W_Cube{numiter};
M1=full(M1);
M2=M-M1;
[addrow addcol]=find(M2==1);
add=[addrow addcol];
[minrow mincol]=find(M2==-1);
minus=[minrow mincol];
% 加边减边
% 以下是加点减点
minusnode=[];
for i=1:size(M,1)
    if(M(i,:)==0)
        if(M1(i,:)==0)
        else
            minusnode=[minusnode i];
        end
    end
end

addnode=[];
for i=1:size(M1,1)
    if(M1(i,:)==0)
        if(M(i,:)==0)
        else
            addnode=[addnode i];
        end
    end
end    
% 加边中去除加点的情况
for i=1:size(addnode,2)
    [noderow nodecol]=find(add==addnode(i));
    add(noderow,:)=[];
end

% for i=1:size(minusnode,2)
%     [noderow nodecol]=find(minus==minusnode(i));
%     minus(noderow,:)=[];
% end
inter_add=[]; %统计出所有增加的社团间的边

for n=1:size(add,1)
    for q=1:size(bestCC,2)
        if(find(bestCC{1,q}==add(n,1)))
            if(find(bestCC{1,q}==add(n,2)))
            else   
                inter_add=[inter_add;add(n,:)];
            end
        end
    end
end

intra_minus=[]; %统计出所有减少的社团内的边
for n=1:size(minus,1)
    for q=1:size(bestCC,2)
        if(find(bestCC{1,q}==minus(n,1)))
            if(find(bestCC{1,q}==minus(n,2)))
                  intra_minus=[intra_minus;minus(n,:)];
            end
        end
    end
end

minus_Neighbor=[];
for i=1:size(minusnode,2)
  minus_Neighbor=[minus_Neighbor transfer_Neighbor{1,minusnode(i)}];
end




add=inter_add;
minus=intra_minus;
