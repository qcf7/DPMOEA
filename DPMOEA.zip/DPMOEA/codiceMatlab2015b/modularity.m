function mod = modularity(CC,M);
         mod=0;
         numEdges=sum(sum(M(:,:)));
        
         for k=1:size(CC,2)
                                             %che formano la componente corrente
            listnodes=CC{k};   
    %ls is the number of edges joining nodes of the community k
    %ds is the sum of the degrees of the nodes belonging to the community k
            ls=sum(sum(M(listnodes,listnodes)));
            ds=sum(sum(M(listnodes,:)));
            if (ds >0)
              mod = mod + (ls/numEdges - (ds/numEdges)^2);
            end
            
         end
    end