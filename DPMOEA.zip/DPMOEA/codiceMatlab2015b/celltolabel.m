function label = celltolabel(divid,numnodes)
     label=zeros(1,numnodes);
     for i=1:size(divid,2)
         for m=1:size(divid{1,i},2)
             label(divid{1,i}(m))=i;
         end
     end
end

