col=size(GT_Cube,2);
for i=1:col
    q=zeros(1,size(GT_Cube{1,i},1));
    for u=1:size(GT_Cube{1,i},1)
       if  isempty(find(GT_Cube{1,i}(u,:)~=0))
           q(u)=0;
       else
        q(u)=find(GT_Cube{1,i}(u,:)~=0);
       end
    end
    GT_Cube(i)={q};
end
    