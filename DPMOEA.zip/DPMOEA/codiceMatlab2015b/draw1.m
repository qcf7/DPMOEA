

%性能表现
% load('result/MOEA-EMT/K/56/pinlv_EMT_500_01_1.mat');
% plot(ParetoValue(:,1),ParetoValue(:,2),'ro');
% hold on
% load('result/MOEA-Probs/K/56/Probs_500_001_1.mat');
% plot(ParetoValue_Probs(:,1),ParetoValue_Probs(:,2),'bx');
% hold on
% load('result/PMOEA/K/56/PMOEA_500_001_1.mat');
% plot(ParetoValue_PMOEA(:,1),ParetoValue_PMOEA(:,2),'*k');
% hold on
% load('result/NewCrossPMOEA/K/56/NewCrossPMOEA_500_001_1.mat');
% plot(ParetoValue_NewCrossPMOEA(:,1),ParetoValue_NewCrossPMOEA(:,2),'h');
% hold on
% load('result/MOMFEA/K/56/MOMFEA_500_001_1.mat');
% plot(-T1_Value(1:50),-T1_Value(51:100),'^');
% hold on
% load('result/MOMFEA2/K/56/MOMFEA2_500_001_1.mat');
% plot(-T1_Value(1:50),-T1_Value(51:100),'*');
% hold on
% xlabel("Predict Ratings");
% ylabel("Topic Diversity");
% legend("MOREM","MOEA-Probs",'PMOEA','NewCrossPMOEA','MOMFEA','MOMOFEA-II');

%Precision
% load("D:/my/Experiment/Douban-1/data/K/data_Douban1_56_264.mat");
% load('result/MOEA-EMT/K/56/pinlv_EMT_500_01_1.mat');
% pre1=Precision(ParetoSolution,TestData,numofuser);
% plot(pre1,ParetoValue(:,2),'ro');
% hold on
% load('result/MOEA-Probs/K/56/Probs_500_001_1.mat');
% pre2=Precision(ParetoSolution_Probs,TestData,numofuser);
% plot(pre2,ParetoValue_Probs(:,2),'xb');
% hold on
% load('result/PMOEA/K/56/PMOEA_500_001_1.mat');
% pre3=Precision(ParetoSolution_PMOEA,TestData,numofuser);
% plot(pre3,ParetoValue_PMOEA(:,2),'*k');
% hold on
% load('result/NewCrossPMOEA/K/56/NewCrossPMOEA_500_001_1.mat');
% pre4=Precision(ParetoSolution_NewCrossPMOEA,TestData,numofuser);
% plot(pre4,ParetoValue_NewCrossPMOEA(:,2),'h');
% hold on
% load('result/MOMFEA/K/56/MOMFEA_500_001_1.mat');
% pre5=Precision(Population_1,TestData,numofuser);
% plot(pre5,-T1_Value(51:100),'^');
% hold on
% load('result/MOMFEA2/K/56/MOMFEA2_500_001_1.mat');
% pre6=Precision(Population_1,TestData,numofuser);
% plot(pre6,-T1_Value(51:100),'^');
% hold on
% xlabel("Precision");
% ylabel("Topic Diversity");
% legend('MOREM','MOEA-Probs','PMOEA','NewCrossPMOEA','MOMFEA','MOMOFEA-II');


%HV值
% HV_rs=zeros(10,1);
% for i=1:1
% eval(['load(''result/MOEA-EMT/K/56/pinlv_EMT_500_01_',num2str(i),'.mat'');']);
% HV_rs(i)=HV(ParetoValue);
% eval(['load(''result/MOEA-Probs/K/56/Probs_500_001_',num2str(i),'.mat'');']);
% HV_rs(i)=HV(ParetoValue_Probs);
% eval(['load(''result/PMOEA/K/56/PMOEA_500_001_',num2str(i),'.mat'');']);
% HV_rs(i)=HV(ParetoValue_PMOEA);
% eval(['load(''result/NewCrossPMOEA/K/56/NewCrossPMOEA_500_001_',num2str(i),'.mat'');']);
% HV_rs(i)=HV(ParetoValue_NewCrossPMOEA);
% eval(['load(''result/MOMFEA/K/56/MOMFEA_500_001_',num2str(i),'.mat'');']);
% ParetoValue(:,1)=-T1_Value(1:50);
% ParetoValue(:,2)=-T1_Value(51:100);
% HV_rs(i)=HV(ParetoValue);
% eval(['load(''result/MOMFEA2/K/56/MOMFEA2_500_001_',num2str(i),'.mat'');']);
% ParetoValue(:,1)=-T1_Value(1:50);
% ParetoValue(:,2)=-T1_Value(51:100);
% HV_rs(i)=HV(ParetoValue);
% end
% HV_mean=mean(HV_rs);

% 分组策略
% load('result/MOEA-EMT/K/56/pinlv_EMT_500_01_1.mat');
% plot(ParetoValue(:,1),ParetoValue(:,2),'ro');
% hold on
% load('result/MOEA-EMT-suiji/K/56/1_suiji_EMT_500_001_1.mat');
% plot(ParetoValue(:,1),ParetoValue(:,2),'xb');
% hold on
% xlabel("Predict Ratings");
% ylabel("Topic Diversity");
% legend('MOREM','MOREM(-TG)');

%原始任务
% load('result/MOEA-EMT/K/56/pinlv_EMT_500_01_1.mat');
% plot(ParetoValue(:,1),ParetoValue(:,2),'or');
% hold on
% load('result/MOEA-Probs/K/56/Probs_500_001_1.mat');
% plot(ParetoValue_Probs(:,1),ParetoValue_Probs(:,2),'bx');
% hold on
% xlabel("Predict Ratings");
% ylabel("Topic Diversity");
% legend('MOREM','MOREM(-KT)');

%辅助任务

plot(scores(:,1),scores(:,2),'or');
hold on

plot(scores1(:,1),scores1(:,2),'bx');
hold on
xlabel("Predict Ratings");
ylabel("Topic Diversity");
legend('MOREM','MOREM(-KT)');
