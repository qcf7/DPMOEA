function important_edge = important_edge(similarity,edge,important_rate)
importantrow=[];
importantcol=[];
for i=1:size(edge,1)
    if edge(i,1)>size(similarity,2)
        continue
    end
    if edge(i,2)>size(similarity,2)
        continue
    end
    if(similarity(edge(i,1),edge(i,2))>important_rate)
        importantrow=[importantrow;edge(i,1)];
        importantcol=[importantcol;edge(i,2)];
    end
   
end
important_edge=[importantrow importantcol];
important_edge=unique(important_edge(:)');
end

