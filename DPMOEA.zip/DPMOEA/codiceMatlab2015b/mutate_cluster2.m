function mutationChildren = mutate_cluster2(parents ,options,NVARS, ...
    FitnessFcn, state, thisScore,thisPopulation,mutationRate,Neighbor);
%
%   The arguments to the function are 
%     PARENTS: Parents chosen by the selection function
%     OPTIONS: Options structure created from GAOPTIMSET
%     NVARS: Number of variables 
%     FITNESSFCN: Fitness function 
%     STATE: State structure used by the GA solver 
%     THISSCORE: Vector of scores of the current population 
%     THISPOPULATION: Matrix of individuals in the current population
%     MUTATIONRATE: Rate of mutation
%     Neighbor a cell array containing the neighbors of each node




mutationChildren = zeros(length(parents),NVARS);


for i=1:length(parents)
  

        child = thisPopulation(parents(i),:);
        for q=1:size(child,2)
        if rand<0.01
        pos = q;
        while (child(pos) == 0) 
            pos = ceil(NVARS*rand);
        end
        valuepos=ceil(size(Neighbor{pos},2)*rand);

        child(pos) = Neighbor{pos}(valuepos);
        end
        end
        mutationChildren(i,:) = child; 
    
    
end