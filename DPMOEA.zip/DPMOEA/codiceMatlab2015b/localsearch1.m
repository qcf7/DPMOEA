function [localpop q]= localsearch1(M, Neighbor, changeNode, pop)
    changeNode=unique(changeNode);
    degree=Neighbor2degree(Neighbor);
    q=randperm(99,60)+1;
    similarity=Tosim_matrix(M,1);
    localpop=[];
    for t=1:size(q,2)
        localpop=[localpop;pop(q(t),:)];
    end
     localNeighbor=cell(1,size(changeNode,2));

    for o=1:size(changeNode,2)
       localNeighbor{1,o} = Neighbor{1,changeNode(o)}; 
    end

    for i=1:size(localpop,1)

            bestCC=decodenew(localpop(i,:));
            
            label=locus2label(localpop(i,:));
            labelafter=label;
            for u=1:size(changeNode,2)
            NodeNeighbor=Neighbor{1,changeNode(u)};
            Expectnode=neighbor_similarity(Neighbor,changeNode(u),bestCC,similarity);
        label = search1(changeNode(u),NodeNeighbor,label,labelafter,M,degree,Expectnode);
        
        
%          if flag==1
%             labelafter=label;
%             changenode=NodeNeighbor;
%              for l=1:size(changenode,2)
%             NodeNeighbor=Neighbor{1,changenode(l)};
%            [label flag NodeNeighbor]=search1(changenode(l),NodeNeighbor,label,labelafter,M,degree);
%              end
%         end
        
        
            end
        
        
       
        localpop(i,:)=vector2locus(label,M);
    end
    
    
end

