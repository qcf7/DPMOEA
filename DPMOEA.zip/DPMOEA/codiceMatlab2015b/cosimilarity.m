function cos = cosimilarity(A)
n_row = size(A,1);
norm_r = sqrt(sum(abs(A).^2,2)); % same as norm(A,2,'rows')
B = zeros(n_row,n_row);
for i = 1:n_row
  for j = i:n_row
    B(i,j) = dot(A(i,:), A(j,:)) / (norm_r(i) * norm_r(j));
    B(j,i) = B(i,j);
  end
end

row=size(B,1);
col=size(B,2);
for i=1:row
    for j=1:col
        if(isnan(B(i,j))==1)
            B(i,j)=0;
        end
        if(i==j)
            B(i,j)=0;
        end
    end
end
cos=B;