function label = locus2label(locus)
CC=decodenew(locus);
label=celltolabel(CC,size(locus,2));
end

